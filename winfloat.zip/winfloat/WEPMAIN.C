//***************************************************************************
//
//  Module:   wepmain.c
//
//  Purpose:
//      Initialization and termination functions for DLL.
//      
//
//  Description of functions:
//      LibMain() - DLL initialization function; called by LibEntry.
//      WEP() - DLL termination function.
//
//  Comments:
//      Uses #pragma code_seg for both functions; see comment blocks.
//         
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

// Speed up compilation by simplifying parsing of windows.h ...

#define NOKERNEL 
#define NOGDI    
#define NOUSER   
#define NOSOUND  
#define NOCOMM   
#define NODRIVERS

#include <windows.h>
#include "floatdll.h"
#include "floatapp.h"

// Functions local to this module ...

int FAR PASCAL LibMain(HMODULE, WORD, WORD, DWORD); // not exported function
int CALLBACK _export WEP (int);


//************************************************************************
//  int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, dwIgnore)
//
//  Description:
//      Initialization function for DLL.  Calls DLLInstallSignalHandler()
//      to install the DLL's signal handler; this is something of a misnomer
//      because it merely sets a flag for the DLL to use later when actually
//      performing floating point.
//      
//
//  Returns:
//      Returns TRUE if signal handler installed; FALSE if not.
//
//  Comments:
//      LibMain() is called by LibEntry.  LibEntry is called by Windows 
//      when the DLL is loaded.  The LibEntry routine is provided in
//      the LIBENTRY.OBJ in the SDK Link Libraries disk.  (The
//      source LIBENTRY.ASM is also provided.)  
//
//      LibEntry initializes the DLL's heap, if a HEAPSIZE value is
//      specified in the DLL's DEF file.  Then LibEntry calls
//      LibMain.  The LibMain function below satisfies that call.
//
//      The LibMain function should perform additional initialization
//      tasks required by the DLL.  In this example, no initialization
//      tasks are required.  LibMain should return a value of 1 if
//      the initialization is successful.
//
//      LibMain does not need to be exported because it is called directly
//      by LibEntry(); the fixup is resolved statically at link-time.
//      
//      This function is forced into INIT_TEXT by the #pragma code_seg 
//      so that it will be loaded (and discarded) along with the function
//      LibEntry().
//
//************************************************************************

#pragma code_seg ("INIT_TEXT")      // force it into LibEntry's segment

int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, dwIgnore)
HMODULE hModule;
WORD    wDataSeg;
WORD    cbHeapSize;
DWORD   dwIgnore;    // This is *not* a commandline; it's passed by 
{                    // LibEntry for compatibility reasons.
    return DLLInstallSignalHandler(SIG_INSTALL);
} // end of LibMain()


//************************************************************************
//  int CALLBACK _export WEP (int);     // no other files need to see this
//
//  Description:
//      Simply returns 1 to indicate success.
//
//  Returns:
//
//
//  Comments:
//      Performs cleanup tasks when the DLL is unloaded.  WEP() is
//      called automatically by Windows when the DLL is unloaded (no
//      remaining tasks still have the DLL loaded).  It is strongly
//      recommended that a DLL have a WEP() function, even if it does
//      nothing but returns success (1), as in this example.
//
//      WEP() is placed in its own segment (WEP_TEXT) via the
//      code_seg #pragma.  This segment is then marked PRELOAD
//      FIXED in the .DEF file.  Finally, the WEP() is marked
//      RESIDENTNAME so the KERNEL can call it in any situation, 
//      including low memory.
//
//  History:   Date       Author      Comment
//              4/ 1/92   DavidL      Added this nifty comment block.
//************************************************************************

#pragma code_seg ("WEP_TEXT")       // force this code into its own segment

int CALLBACK _export WEP (nExitType)
int  nExitType;     // termination code: WEP_FREE_DLL or WEP_SYSTEM_EXIT
{
    return(1);      // success
} 

//***************************************************************************
//  End of File: wepmain.c
//***************************************************************************


