//  SHOW87.C
//
//  Simple program to disable HIDE87's masking of the Int 11h BIOS equipment 
//  word coprocessor bit.  All it does is issue an Int 11h with AX set to
//  444Ch.  If HIDE87's TSR is installed, it will respond to this by 
//  disabling its masking.  The effect of this is to make the coprocessor
//  visible to any software --such as Windows-- that detects it via Int 11h.  
//  If HIDE87 is not installed, there is no harm ... the value in AX will 
//  simply be ignored by the BIOS Int 11h handler.
//  
//  To affect Windows' awareness of the presence|absence of a coprocessor,
//  Windows must be [re-]started after running HIDE87 or SHOW87.
//
//  There is no harm in using this program (along with HIDE87) on a machine 
//  that does not have a coprocessor, but there will be no change in 
//  behavior because the BIOS already returns 0 for the coprocessor bit.
//  
//  Reference:
//        AX = 444Ch      turn off mask (let coprocessor be seen)      
//        AX = 646Ch      turn on mask  (hide coprocessor)

// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <stdio.h>

void main(void)
{
    // Tell HIDE87 (if it's there) to stop masking coprocessor...
    _asm mov ax, 444Ch
    _asm int 11h

    puts("HIDE87 deactivated - coprocessor masking off.");
    puts("       Use HIDE87 to activate.");
}
