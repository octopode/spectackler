//***************************************************************************
//
//  Module:   FPStuff.c
//
//  Purpose:
//      Contains application-specific code related to floating point.
//      The file FLOATAPP.C makes initialization calls to detect the 
//      coprocessor, and the WM_COMMAND processing code calls the 
//      remaining functions contained in this file.  FPSIG.C contains
//      functions common to both the App and DLL, all dealing with 
//      signal generation and handling.
//
//  Description of functions:
//      TestFloatSpeed()        Timing test for floating point speed.
//      FPMaskExceptions()      Allows or prevents exceptions.
//      CheckCoprocessor()      Checks if Windows thinks 80x87 present.
//      MaskFCW()               workaround to a C6 compiler bug
//
//  Comments:
//      Code which is dependent upon the math package (ALTMATH vs
//      EMULATOR) is bracketed with #ifdef .... #endif pragmas.
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//


#include <windows.h>
#include <float.h>                      // CRT floating point
#include <signal.h>                     // CRT signal function
#include "floatapp.h"                   // app-specific
#include "floatdll.h"                   // dll-specific
#include "fpmath.h"                     // interface to Win87Em's _fpmath()
#define MBSAY                           // output to messagebox
#include "say.h"                        // macros to output messages

#if !defined(EMULATOR) && !defined(ALTMATH)
#pragma message("Warning!  No math package defined; assuming EMULATOR")
#define EMULATOR
#endif

// Variables local to this module ...
                                        
#ifdef EMULATOR
static WORD wFCW_Masked =   0x133f;     // Floating point control word
static WORD wFCW_Unmasked = 0x1320;     // values to [un]mask exceptions.
#endif

// Global variables ...

BOOL fHave87;                           // Used in status reports.
BOOL fMaskExceptions = FALSE;           // Initially, we want them to occur.
extern UINT uNumExceptions;             // declared in fpsig.c
extern BOOL fSignalHandlerInstalled;    // declared in fpsig.c

#ifdef EMULATOR
WORD wExceptionControl = IDM_EC_CONTROL87;
#endif


//************************************************************************
//  void MaskFCW(WORD wFCW)
//
//  Description:
//      Ridiculously simple function that performs one in-line assembly
//      instruction to load the floating point control word.  Called by
//      FPMaskExceptions().  Its placement in the file is important; see
//      comments.
//
//  Returns:
//      void
//
//  Comments:
//      There is no good reason this function exists ... but there is 
//      a bad one: the Microsoft C 6.0 compiler gags at compile-time 
//      with bogus syntax errors if this one line of _asm code is put
//      back into FPMaskExceptions().  Version 7.0 of Microsoft C 
//      corrects this problem.  This compiler bug is sensitive to the
//      location of this function within the file, so don't move it. 
//
//************************************************************************

void MaskFCW(WORD wFCW)
{
    _asm fldcw wFCW
} // end of MaskFCW()


//************************************************************************
//  BOOL FPMaskExceptions(fMask)
//
//  Description:
//      Sets the floating point control word to mask or unmask floating
//      point exceptions. 
//
//  Returns:
//      TRUE if exceptions are masked.
//      FALSE if not.
//
//  Comments:
//      The INEXACT mask is left even in the "cleared" state because
//      this exception occurs all the time and is better left to the
//      80x87 to handle.  
//
//      Does nothing in AltMath mode because this math package doesn't
//      provide this kind of control.
//
//************************************************************************

BOOL FPMaskExceptions(fMask)
BOOL fMask;     // TRUE = mask them; FALSE = unmask them
{
#ifdef EMULATOR
    WORD wFCW;

    if (fMask)
        wFCW = wFCW_Masked;
    else
        wFCW = wFCW_Unmasked;

    switch(wExceptionControl)
    {
    case IDM_EC_DIRECT:
        if (fHave87)
            MaskFCW(wFCW);
        else
            DebugSay("Cannot FLDCW when no 80x87!");
        break;
    
    case IDM_EC_CONTROL87:
        wFCW = _control87(wFCW, 0xffff);
        break;

    case IDM_EC_FPMATH:
        FPMATH_FLDCW(wFCW);
        break;
    }
#endif
    return fMask;
} // end of FPMaskExceptions()


//************************************************************************
//  DWORD TestFloatSpeed(UINT)
//
//  Description:
//  	Tests speed of floating point operations with the current compiler
//      options, math libraries, math coprocessor (or lack thereof), and
//      coding techniques.  Iterates 262,140 times (4 * FFFFh) through 
//      floating point addition, subtraction, multiplication and division.
//
//  Returns:
//      Time (in milliseconds) to perform test loop.
//
//  Comments:
//      Note that --on a 33MHz 80386-- this test can take anywhere from
//      4 seconds to 86 seconds, so be patient.
//************************************************************************

#pragma optimize ("", off)      // the compiler is too tricky for this
                                // simplistic test, so make it stupid
DWORD TestFloatSpeed(uTestType)
UINT uTestType;                         // Reserved: pass in 0.
{
    HCURSOR hCursor;
    DWORD dwStartTime, dwEndTime;       // tick counts for timing operation
    DWORD dwCalcTime;                   // time spent calculating
    UINT i, j;                          // loop counters
    double Double1, Double2, Double3;   // scratch fp variables 

    if ( MessageBox ( 0,
            "This can take anywhere from seconds to minutes,\n" \
            "depending on your hardware and the math package chosen.",
            "Floating point performance test...",
            MB_TASKMODAL|MB_OKCANCEL )
       == IDCANCEL
       )
        return 0L;  // user cancelled test, so return
    // else user pressed IDOK, so we do the test
    hCursor = LoadCursor(NULL, IDC_WAIT);
    hCursor = SetCursor(hCursor);
    dwStartTime = GetTickCount();

    Double1 = 1.0;                      // Initialize the variables
    Double2 = 2.0;                      // to some simplistic starting
    Double3 = 3.0;                      // values.

    for (i=0; i < 4; i++)               // Let's party for awhile ...
    {
        for (j=0; j < 0xffff; j++)
        {
            Double1 = Double2 + Double3;   
            Double1 = Double2 * Double3;   
            Double1 = Double2 - Double3;   
            Double1 = Double2 / Double3;    // this causes an inexact 
        }                                   // exception unless it's masked.
    }
    dwEndTime = GetTickCount();
    SetCursor(hCursor);
    MessageBeep(0);
    dwCalcTime = dwEndTime - dwStartTime;       // accurate +/- 55ms
    Say1("Done!  Time spent calculating = %lu milliseconds", dwCalcTime);
    return (dwCalcTime);
} // end of TestFloatSpeed()

#pragma optimize ("", on)   // restore default optimization settings

//************************************************************************
//  BOOL CheckCoprocessor(void)
//
//  Description:
//      Checks to see if there is a coprocessor present by examining
//      WinFlags.  There are other ways to do this, including:
//       1. __fpmath() - interface to Win87Em
//       2. Int 11h - BIOS equipment check
//       3. A careful series of fp instructions and tests as specified
//          by Intel, documented in the Intel 80387 Programmer's 
//          Reference Manual.  This last method is more robust, and 
//          would not be fooled by the HIDE87 TSR.
//      
//      We are only interested in knowing if Windows thinks there is
//      a coprocessor present, so we test WinFlags since that's easiest.
//      The __fpmath() routine in Win87Em just uses WinFlags, anyway.
//          
//  Returns:
//      TRUE if coprocessor present.
//      FALSE if not.
//
//************************************************************************

BOOL CheckCoprocessor(void)
{
    return (BOOL) (GetWinFlags() & WF_80x87);
} // end of CheckCoprocessor()


//***************************************************************************
//  End of File: FPStuff.c
//***************************************************************************

