//***************************************************************************
//
//  Module:   FloatApp.c
//
//  Purpose:
//      Demonstrates floating point in Windows.  Allows generation and
//      handling of floating point exceptions, masking and unmasking the
//      floating point control word, detection of coprocessor, and 
//      benchmarking floating point performance.  Some options (such as 
//      the control word) are not available in the Alternate math package, 
//      and therefore are conditionally compiled (see #ifdef statements).
//
//  Description of functions:
//	    WinMain() - calls initialization function, processes message loop
//	    InitApplication() - initializes window data and registers window
//	    InitInstance() - saves instance handle and creates main window
//	    MainWndProc() - processes messages
//	    About() - processes messages for "About" dialog box
//
//  Comments:
//      Pay attention to the use of #ifdef and #if defined statements
//      for conditional compilation.  This code works for both Emulator
//      and Alternate math, but there are differences.
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//


#include <windows.h>            // Required for all Windows applications
#include <float.h>              // needed for fp constants, exceptions
#include "FloatApp.h"           // Specific to this program		    
#include "FloatDLL.h"           // Exported functions from DLL
#include "fpmath.h"             // Interface to Win87Em
#include "say.h"

#if !defined(EMULATOR) && !defined(ALTMATH)
#pragma message("Warning!  No math package defined; assuming EMULATOR")
#define EMULATOR
#endif

// Global variables...

static HMENU hmenuDLL_SIG_POPUP;// Used only in this module; WM_INITMENUPOPUP
HINSTANCE hInst;                // Current instance of app
WORD   wRegMsg;                 // Used to notify that update is needed
extern BOOL fMaskExceptions;    // declared in fpstuff.c
extern BOOL fHave87;            // declared in fpstuff.c
extern UINT uNumExceptions;             // declared in fpsig.c
extern BOOL fSignalHandlerInstalled;    // declared in fpsig.c
WORD wWidth;

#ifdef EMULATOR
extern WORD wExceptionControl;  // declared in fpstuff.c
#endif


//************************************************************************
//  int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
//
//  Description:
//      Entry point function for application.  Initializes app, 
//      initializes instance, and enters message loop.
//
//************************************************************************

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HINSTANCE hInstance;			        // current instance
HINSTANCE hPrevInstance;			    // previous instance
LPSTR lpCmdLine;			            // command line
int    nCmdShow;				        // show-window type (open/icon)
{
    MSG msg;				            // message

    if (!hPrevInstance)			        // Other instances of app running?
	if (!InitApplication(hInstance))    // Initialize shared things 
	    return (FALSE);		            // Exits if unable to initialize    

    // Perform initializations that apply to a specific instance

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    // Acquire and dispatch messages until a WM_QUIT message is received.

    while (GetMessage(&msg,	    // message structure
	    NULL,		            // handle of window receiving the message
	    NULL,		            // lowest message to examine		    
	    NULL))		            // highest message to examine	    
	{
	TranslateMessage(&msg);	    // Translates virtual key codes
	DispatchMessage(&msg);	    // Dispatches message to window
    }
    return (msg.wParam);	    // Returns the value from PostQuitMessage
} // end of WinMain()


//************************************************************************
//  BOOL InitApplication(hInstance)
//
//  Description:
//      Initializes window data and registers window class.  Checks for
//      presence of math coprocessor and stores result in global variable
//      fHave87.
//
//  Comments:
//
//      This function is called at initialization time only if no other 
//      instances of the application are running.  This function performs 
//      initialization tasks that can be done once for any number of running 
//      instances.  
//
//      In this case, we initialize a window class by filling out a data 
//      structure of type WNDCLASS and calling the Windows RegisterClass() 
//      function.  Since all instances of this application use the same window 
//      class, we only need to do this when the first instance is initialized.  
//
//************************************************************************

BOOL InitApplication(hInstance)
HINSTANCE hInstance;			       // current instance
{
    WNDCLASS  wc;

    // Fill in window class structure with parameters that describe the       
    // main window.                                                           

    wc.style = NULL;                    // Class style(s).                    
    wc.lpfnWndProc = MainWndProc;       // Function to retrieve messages for  
                                        // windows of this class.             
    wc.cbClsExtra = 0;                  // No per-class extra data.           
    wc.cbWndExtra = 0;                  // No per-window extra data.          
    wc.hInstance = hInstance;           // Application that owns the class.   
    wc.hIcon = LoadIcon(hInstance, "FloatAppIcon");
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "FloatAppMenu";   // Name of menu resource in .RC file. 
    wc.lpszClassName = "FloatAppWClass"; // Name used in call to CreateWindow. 

    // Register the window class and return success/failure code.

    return (RegisterClass(&wc));
} // end of InitApplication()


//************************************************************************
//  BOOL InitInstance(hInstance, nCmdShow)
//
//  Description:
//      Saves instance handle and creates main window.
//      If using Alternate math library, disables menu items to 
//      mask/unmask exceptions (only available in Emulator math).
//      If using Emulator mask, clears the floating point control
//      word exception mask so exceptions will occur.
//      Registers application's signal handler.
//
//  Comments:
//      This function is called at initialization time for every instance of 
//      this application.  This function performs initialization tasks that 
//      cannot be shared by multiple instances.  
//
//      In this case, we save the instance handle in a static variable and 
//      create and display the main program window.  
//
//************************************************************************

BOOL InitInstance(hInstance, nCmdShow)
HINSTANCE hInstance;                // Current instance identifier.      
UINT      nCmdShow;                 // Param for first ShowWindow() call.
{
    HWND            hWnd;               // Main window handle. 

    if ((wRegMsg = RegisterWindowMessage((LPSTR)"Dave's Float App")) == 0)
        return (FALSE);

    // Save the instance handle in static variable, which will be used in
    // many subsequence calls from this application to Windows.          

    hInst = hInstance;

    // Create a main window for this application instance

    hWnd = CreateWindow(
        "FloatAppWClass",               // See RegisterClass() call.        
        "FloatApp",                     // Text for window title bar.       
        WS_OVERLAPPEDWINDOW,            // Window style.                     
        CW_USEDEFAULT,                  // Default horizontal position.      
        CW_USEDEFAULT,                  // Default vertical position.        
        CW_USEDEFAULT,                  // Default width.                    
        CW_USEDEFAULT,                  // Default height.                   
        NULL,                           // Overlapped windows have no parent.
        NULL,                           // Use the window class menu.        
        hInstance,                      // This instance owns this window.   
        NULL                            // Pointer not needed.               
    );

    // If window could not be created, return "failure" 

    if (!hWnd)
        return (FALSE);

    fHave87 = CheckCoprocessor();

#ifdef EMULATOR     // we're in EMULATOR math...
    if (!fHave87)   // if we don't have a coprocessor, disable FCW menu item
    {
        HMENU hMenu = GetMenu(hWnd);
        EnableMenuItem(hMenu, IDM_EC_DIRECT, MF_GRAYED | MF_DISABLED);
    }
    FPMaskExceptions(FALSE);   // Clear 87 control word to allow exceptions.
#endif

    // Get the menu handle for the DLL popup menu of the Signal popup
    // menu.  GetSubMenu is 0-based, and both these are the second items
    // in their lists.  Store value in global variable for later use at
    // WM_MENUINITPOPUP time.
    if ((hmenuDLL_SIG_POPUP = GetSubMenu(GetSubMenu(GetMenu(hWnd), 1), 1))
        == (HMENU) 0)
            DebugSay("Couldn't obtain menu handle for hmenuDLL_SIG_POPUP");
    
    // Initially, set the signal handler to be the application's own;
    // the user can change this later with menu choices...

    InstallSignalHandler(SIG_INSTALL);

    // Make the window visible; update its client area; and return "success"

    ShowWindow(hWnd, nCmdShow);  // Show the window                        
    UpdateWindow(hWnd);          // Sends WM_PAINT message                 
    return (TRUE);               // Returns the value from PostQuitMessage 
} // end of InitInstance()


//************************************************************************
//  LRESULT CALLBACK MainWndProc(hWnd, message, wParam, lParam)
//
//  Description:
//      Processes messages for main window procedure:
//	        WM_COMMAND          application menu (About dialog box)
//          WM_DESTROY          destroy window
//          WM_INITMENUPOPUP    determine what state of checkmarking and
//                              graying is correct for current app and DLL 
//                              floating point settings.
//          WM_PAINT            Redraws the screen by painting current 
//                              floating point status in the client area. 
//          WM_DESTROY          terminate the app by posting a quit msg
//          
//  Comments:
//      The WM_COMMAND section is really the "heart" of the application. It
//      is here that the floating point functions are exercised, and here
//      that the state machine logic is implemented to keep track of what 
//      mode we're in (exceptions masked/unmasked, signal handler installed 
//      vs uninstalled, etc).  
//      
//
//************************************************************************

LRESULT CALLBACK MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;                          // window handle
UINT message;	                    // type of message
WPARAM wParam;	                    // additional information
LPARAM lParam;	                    // additional information
{
    DLGPROC lpProcAbout;		    // pointer to the "About" function 
    BOOL fUpdateWnd;

    switch (message)
    {
    case WM_INITMENUPOPUP:
        if ((HMENU) wParam == hmenuDLL_SIG_POPUP)
        // If this is the DLL signal handler popup menu, we need to query
        // the DLL about what state it's in so we know which items to 
        // enable/disable and check/uncheck.
        {
            DWORD dwDLLStatus = DLLGetStatus(0);
            HMENU hMenu = GetMenu(hWnd);

            // Find out what math library the DLL was compiled with; if not 
            // EMULATOR, disable Save/Restore menuitem.
            if (LOWORD(dwDLLStatus) & DLL_ALTMATH)
                EnableMenuItem(hMenu, IDM_DLL_SIG_SAVE_RESTORE,
                    MF_GRAYED | MF_DISABLED);
            else
            // Find out what the DLL's Save/Restore state is, and set the
            // menu item checkmark appropriately

            if (dwDLLStatus & DLL_SIG_SAVE_RESTORE)
                CheckMenuItem(hMenu, IDM_DLL_SIG_SAVE_RESTORE, MF_CHECKED);
            else
                CheckMenuItem(hMenu, IDM_DLL_SIG_SAVE_RESTORE, MF_UNCHECKED);

            // Find out if the DLL is using its own signal handler, and adjust
            // menu items accordingly...
        
            if (dwDLLStatus & DLL_SIG_INSTALLED)
            {
                EnableMenuItem(hMenu, IDM_DLL_SIG_INSTALL,
                    MF_DISABLED | MF_GRAYED);
                EnableMenuItem(hMenu, IDM_DLL_SIG_REMOVE, MF_ENABLED);
            }
            else
            {
                EnableMenuItem(hMenu, IDM_DLL_SIG_INSTALL, MF_ENABLED);
                EnableMenuItem(hMenu, IDM_DLL_SIG_REMOVE,
                    MF_DISABLED | MF_GRAYED);
            }
            return 0;
        }
        else
            return 1;

	case WM_COMMAND:	            // message: command from application menu
        fUpdateWnd = FALSE;
        switch (wParam)
        {
        case IDM_ABOUT:
            lpProcAbout=(DLGPROC)MakeProcInstance((FARPROC)About,hInst);
		    DialogBox(hInst,		    // current instance	 
		        "AboutBox",			    // resource to use	     
		        hWnd,			        // parent handle	     
		        lpProcAbout);		    // About() instance address 
            FreeProcInstance((FARPROC)lpProcAbout);
		    break;

        case IDM_SPEED:
            TestFloatSpeed(0);
            break;

#ifdef EMULATOR     // none of the following choices are available in ALTMATH
        case IDM_EC_CONTROL87:
            {
            HMENU hMenu = GetMenu(hWnd);
            CheckMenuItem(hMenu, IDM_EC_CONTROL87, MF_CHECKED);
            CheckMenuItem(hMenu, IDM_EC_FPMATH,    MF_UNCHECKED);
            CheckMenuItem(hMenu, IDM_EC_DIRECT,     MF_UNCHECKED);
            wExceptionControl = IDM_EC_CONTROL87;    // set global 
            } break;
        
        case IDM_EC_DIRECT:
            {
            HMENU hMenu = GetMenu(hWnd);
            CheckMenuItem(hMenu, IDM_EC_CONTROL87, MF_UNCHECKED);
            CheckMenuItem(hMenu, IDM_EC_FPMATH,    MF_UNCHECKED);
            CheckMenuItem(hMenu, IDM_EC_DIRECT,    MF_CHECKED);
            wExceptionControl =  IDM_EC_DIRECT;    // set global 
            } break;

        case IDM_EC_FPMATH:
            {
            HMENU hMenu = GetMenu(hWnd);
            CheckMenuItem(hMenu, IDM_EC_CONTROL87, MF_UNCHECKED);
            CheckMenuItem(hMenu, IDM_EC_FPMATH,    MF_CHECKED);
            CheckMenuItem(hMenu, IDM_EC_DIRECT,    MF_UNCHECKED);
            wExceptionControl =  IDM_EC_FPMATH;    // set global 
            } break;

        case IDM_MASK_EXCEPTIONS:
            {
            HMENU hMenu = GetMenu(hWnd);
            CheckMenuItem(hMenu, IDM_MASK_EXCEPTIONS, MF_CHECKED);
            CheckMenuItem(hMenu, IDM_UNMASK_EXCEPTIONS, MF_UNCHECKED);
            fMaskExceptions = TRUE;     // set the global for use elsewhere
            FPMaskExceptions(fMaskExceptions);
            fUpdateWnd = TRUE;
            } break;

        case IDM_UNMASK_EXCEPTIONS:
            {
            HMENU hMenu = GetMenu(hWnd);
            CheckMenuItem(hMenu, IDM_MASK_EXCEPTIONS, MF_UNCHECKED);
            CheckMenuItem(hMenu, IDM_UNMASK_EXCEPTIONS, MF_CHECKED);
            fMaskExceptions = FALSE;    // set the global for use elsewhere
            FPMaskExceptions(fMaskExceptions);
            fUpdateWnd = TRUE;
            } break;
#endif // EMULATOR

        case IDM_APP_ZERODIVIDE:
            GenerateFPException(FPE_ZERODIVIDE);
            fUpdateWnd = TRUE;
            break;

        case IDM_APP_OVERFLOW:
            GenerateFPException(FPE_OVERFLOW);
            fUpdateWnd = TRUE;
            break;

        case IDM_APP_UNDERFLOW:
            GenerateFPException(FPE_UNDERFLOW);
            fUpdateWnd = TRUE;
            break;

        case IDM_APP_INVALID:
            GenerateFPException(FPE_INVALID);
            fUpdateWnd = TRUE;
            break;

        case IDM_DLL_ZERODIVIDE:
            DLLGenerateFPException(FPE_ZERODIVIDE);
            fUpdateWnd = TRUE;
            break;

        case IDM_DLL_OVERFLOW:
            DLLGenerateFPException(FPE_OVERFLOW);
            fUpdateWnd = TRUE;
            break;

        case IDM_DLL_UNDERFLOW:
            DLLGenerateFPException(FPE_UNDERFLOW);
            fUpdateWnd = TRUE;
            break;

        case IDM_DLL_INVALID:
            DLLGenerateFPException(FPE_INVALID);
            fUpdateWnd = TRUE;
            break;

        case IDM_APP_SIG_INSTALL:
            {
            HMENU hMenu = GetMenu(hWnd);
            EnableMenuItem(hMenu, IDM_APP_SIG_INSTALL,
                           MF_DISABLED | MF_GRAYED);
            EnableMenuItem(hMenu, IDM_APP_SIG_REMOVE, MF_ENABLED);
            InstallSignalHandler( SIG_INSTALL );
            fUpdateWnd = TRUE;
            } break;

        case IDM_APP_SIG_REMOVE:
            {
            HMENU hMenu = GetMenu(hWnd);
            EnableMenuItem(hMenu, IDM_APP_SIG_INSTALL, MF_ENABLED);
            EnableMenuItem(hMenu, IDM_APP_SIG_REMOVE,
                           MF_DISABLED | MF_GRAYED);
            InstallSignalHandler( SIG_REMOVE );
            fUpdateWnd = TRUE;
            }break;

        case IDM_DLL_SIG_INSTALL:
            {
            HMENU hMenu = GetMenu(hWnd);
            EnableMenuItem(hMenu, IDM_DLL_SIG_INSTALL,
                           MF_DISABLED | MF_GRAYED);
            EnableMenuItem(hMenu, IDM_DLL_SIG_REMOVE, MF_ENABLED);
            DLLInstallSignalHandler(SIG_INSTALL);
            fUpdateWnd = TRUE;
            } break;

        case IDM_DLL_SIG_REMOVE:
            {
            HMENU hMenu = GetMenu(hWnd);
            EnableMenuItem(hMenu, IDM_DLL_SIG_INSTALL, MF_ENABLED);
            EnableMenuItem(hMenu, IDM_DLL_SIG_REMOVE,
                           MF_DISABLED | MF_GRAYED);
            DLLInstallSignalHandler(SIG_REMOVE);
            fUpdateWnd = TRUE;
            }break;

        case IDM_DLL_SIG_SAVE_RESTORE:  // toggles the save/restore state
            {
            HMENU hMenu = GetMenu(hWnd);

            if (GetMenuState(hMenu, IDM_DLL_SIG_SAVE_RESTORE, MF_BYCOMMAND)
                & MF_CHECKED)
            {
                CheckMenuItem(hMenu, IDM_DLL_SIG_SAVE_RESTORE, MF_UNCHECKED);
                DLLSetStatus(IDM_DLL_SIG_NOSAVE_RESTORE);
            }
            else
            {
                CheckMenuItem(hMenu, IDM_DLL_SIG_SAVE_RESTORE, MF_CHECKED);
                DLLSetStatus(IDM_DLL_SIG_SAVE_RESTORE);
            }
            fUpdateWnd = TRUE;
            }break;

	    default:			            // Let Windows process it
		    return (DefWindowProc(hWnd, message, wParam, lParam));
        }
        if (fUpdateWnd);
            SendMessage(HWND_BROADCAST, wRegMsg, 0, 0);
        break;

	case WM_DESTROY:		        // message: window being destroyed
	    PostQuitMessage(0);
	    break;

	case WM_PAINT:			        // message: window needs painting
        {
        PAINTSTRUCT PS;
        char szString[80];
	    DWORD dwDLLStatus = DLLGetStatus(0);
	    WORD wFCW;
        char * szMath[2] = {"Emulator", "AltMath"};
        DWORD dwHW;
        WORD wHt;

#if defined(EMULATOR)           // Defined by makefile, not compiler
        UINT uMathName = MATH_EMULATOR;
#else
        UINT uMathName = MATH_ALTERNATE;
#endif

        BeginPaint(hWnd, (LPPAINTSTRUCT) &PS);
        dwHW = GetTextExtent(PS.hdc, (LPSTR) "Signal Handler:", 15);
        wWidth = LOWORD(dwHW) * 2;
        wHt = HIWORD(dwHW) + 1;
        lstrcpy((LPSTR)szString, (LPSTR)"Coprocessor:");
        TextOut(PS.hdc, 4, 4, (LPSTR)szString, lstrlen(szString));
        lstrcpy((LPSTR)szString, (LPSTR)(fHave87 ? "Present" : "None"));
        TextOut(PS.hdc, wWidth, 4, (LPSTR)szString, lstrlen(szString));

// Control word ...

        lstrcpy(szString, "Control Word:");
        TextOut(PS.hdc, 4, 4 + wHt, (LPSTR)szString, lstrlen(szString));
    	if (fHave87)
    	{
        	_asm    fstcw wFCW      // Ask the coprocessor what it is...
        	wsprintf(szString, "%#04x  (80x87)", wFCW);
    	}
        else
            wsprintf(szString, "Not Applicable");
        TextOut(PS.hdc, wWidth, 4 + wHt,(LPSTR)szString,lstrlen(szString));

#if defined(EMULATOR)
        FPMATH_FSTCW(wFCW);     // Ask Win87Em what its control word is
        wsprintf(szString, "%#04x  (Win87Em)", wFCW);
#elif defined(ALTMATH)
        wsprintf(szString, "Not Applicable");
#endif
        TextOut(PS.hdc, wWidth, 4 + 2 * wHt,(LPSTR)szString,lstrlen(szString));

// Math package ...

    // first report on app's math package
        lstrcpy((LPSTR)szString, (LPSTR)"Math package:");
        TextOut(PS.hdc, 4, 4 + 3 * wHt, (LPSTR)szString, lstrlen(szString));
        wsprintf((LPSTR)szString, (LPSTR)"%s  (App)", (LPSTR)szMath[uMathName]);
        TextOut(PS.hdc, wWidth, 4 + 3 * wHt,(LPSTR)szString,lstrlen(szString));
#if DELETE_ME
#ifdef ALTMATH
    if (fHave87)
      {
        lstrcpy(szString, "(doesn't use coprocessor)");
        TextOut(PS.hdc, wWidth, 4 + 3 * wHt,(LPSTR)szString,lstrlen(szString));
      }
#endif
#endif 

        wsprintf((LPSTR)szString, (LPSTR)"%s  (DLL)",
                  (LPSTR)szMath[(LOWORD(dwDLLStatus) & DLL_ALTMATH)
                          ? MATH_ALTERNATE : MATH_EMULATOR]);
        TextOut(PS.hdc, wWidth, 4 + 4 * wHt,(LPSTR)szString,lstrlen(szString));

#ifdef DELETE_ME
    if (LOWORD(dwDLLStatus) & DLL_ALTMATH)
      {
        lstrcpy(szString, "(doesn't use coprocessor)");
        TextOut(PS.hdc, wWidth, 4 + 4 * wHt,(LPSTR)szString,lstrlen(szString));
      }
#endif

// Exceptions detected by signal handlers ...

    // App ...
        lstrcpy(szString, "Exceptions:");
        TextOut(PS.hdc, 4, 4 + 5 * wHt, (LPSTR)szString, lstrlen(szString));
        wsprintf(szString, "%u  (App)", uNumExceptions);
        TextOut(PS.hdc, wWidth, 4 + 5 * wHt,(LPSTR)szString,lstrlen(szString));

    // DLL ...
        wsprintf(szString, "%u  (DLL)", HIWORD(dwDLLStatus));
        TextOut(PS.hdc, wWidth, 4 + 6 * wHt,(LPSTR)szString,lstrlen(szString));

// Report which signal handler(s) are being used ...

    // App ...
        lstrcpy(szString, "Signal handler:");
        TextOut(PS.hdc, 4, 4 + 7 * wHt, (LPSTR)szString, lstrlen(szString));
        wsprintf(szString, "%s  (App)",
            (LPSTR) (fSignalHandlerInstalled ? "Installed" : "Default"));
        TextOut(PS.hdc, wWidth, 4 + 7 * wHt,(LPSTR)szString,lstrlen(szString));

    // DLL ...
        wsprintf(szString, "%s  (DLL)",
            (LPSTR) ((LOWORD(dwDLLStatus) & DLL_SIG_INSTALLED) ?
                 "Installed" : "Default"));
        TextOut(PS.hdc, wWidth, 4 + 8 * wHt,(LPSTR)szString,lstrlen(szString));

        if (!(LOWORD(dwDLLStatus) & DLL_ALTMATH)) 
        {
            wsprintf(szString, "%sSave/Restore  (DLL)",
                (LPSTR)((LOWORD(dwDLLStatus) & DLL_SIG_SAVE_RESTORE) ? "" : "No "));
            TextOut(PS.hdc, wWidth, 4 + 9 * wHt,(LPSTR)szString,lstrlen(szString));
        }
        EndPaint(hWnd, (LPPAINTSTRUCT) &PS);
        }
	    break;

	default:			            // Passes it on if unproccessed
            if (wRegMsg == message)
            {
                RECT rRect;

                GetClientRect(hWnd, &rRect);
                rRect.left = wWidth - 1;
                InvalidateRect(hWnd, &rRect, TRUE);
            }
	        else
	        	return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (NULL);
} // end of MainWndProc()


//************************************************************************
//  BOOL CALLBACK About(hDlg, message, wParam, lParam)
//
//  Description:
//      Processes messages for "About" dialog box:
//          WM_INITDIALOG - initialize dialog box
//          WM_COMMAND    - Input received
//
//  Comments:
//      No initialization is needed for this particular dialog box, but TRUE
//      must be returned to Windows.
//      
//      Wait for user to click on "Ok" button, then close the dialog box.
//
//************************************************************************

BOOL CALLBACK About(hDlg, message, wParam, lParam)
HWND hDlg;                          // window handle of the dialog box 
UINT message;                       // type of message                 
WPARAM wParam;                      // message-specific information   
LPARAM lParam;
{
    switch (message)
    {
	case WM_INITDIALOG:		        // message: initialize dialog box
	    return (TRUE);

	case WM_COMMAND:		        // message: received a command
        switch (wParam)
        {
	    case IDOK:                  // "OK" box selected?
        case IDCANCEL:              // System menu close command?
		    EndDialog(hDlg, TRUE);	// Exits the dialog box 
		    return (TRUE);
        
        default:
            return (FALSE);         // Didn't process message
        }
    default:
        return (FALSE);             // Didn't process message
    }
} // end of About()


//***************************************************************************
//  End of File: floatapp.c
//***************************************************************************

