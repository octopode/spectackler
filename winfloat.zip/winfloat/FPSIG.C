//***************************************************************************
//
//  Module:   FPSig.c
//
//  Purpose:
//      Generation, handling, and reporting of floating point 
//      exception signals for App and DLL.
//
//  Description of functions:
//      GenerateFPException()   Triggers various FP exceptions.                
//      DLLGenerateFPExceptions()   -ditto for dll-
//      InstallSignalHandler()  Installs or removes signal handler.
//      DLLInstallSignalHandler()   -ditto for dll-
//      FPHandler()             The floating point signal handler.
//      FPExceptionInfo()       Reports what exception type occurred.
//      DLLGetStatus()          Lets app query DLL for its FP status.
//      DLLSetStatus()          Lets app control DLL's use of FPInit/FPTerm.
//
//  Comments:
//      Code which is dependent upon the math package (ALTMATH vs
//      EMULATOR) is bracketed with #ifdef .... #endif pragmas.
//
//      This code is reused in both the Application and DLL.  The
//      DLL version retains the same function entry points, but changes
//      the function names and calling conventions.  For example:
//      
//      Application:                    DLL:
//      ------------                    ----
//      GenerateFPException             DLLGenerateFPException
//      returns BOOL                    returns BOOL
//      default calling convention      FAR PASCAL _export calling convention
//
//      Code which is dependent upon App vs DLL compilation is bracked 
//      with #ifdef ... #endif pragmas.  
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <windows.h>
#include <float.h>                      // CRT floating point
#include <signal.h>                     // CRT signal function
#include "floatapp.h"                   // app-specific
#include "floatdll.h"                   // dll-specific
#include "fpmath.h"                     // interface to Win87Em's _fpmath()
#define MBSAY                           // output to messagebox
#include "say.h"                        // macros to output messages

#if !defined(_WINDOWS) && !defined(_WINDLL)
    #pragma message("Warning!  Neither _WINDOWS nor _WINDLL defined.")        
#endif

#if !defined(EMULATOR) && !defined(ALTMATH)
#pragma message("Warning!  No math package defined; assuming EMULATOR")
#define EMULATOR
#endif

#if defined(C7) && defined(EMULATOR)
// The following function prototype is to allow linking with C7 libs
// and WIN87EM.LIB
void _acrtused2() {};
#endif

// #define ANNOUNCE_EXCEPTION_TRIGGER   // Notifies attempt to cause except.
// #define RESET_EXCEPTION_MASK         // If defined, resets mask for this 
                                        // task before triggering exception.
// Functions local to this module...

void FPHandler(int, int);               // called by InstallSignalHandler
void FPExceptionInfo(UINT);             // called by FPHandler

// Variables local to this module ...

#if defined(_WINDLL)
    static char szModule[] = "DLL";
    #ifdef ALTMATH
        static WORD wDLLStatus = DLL_SIG_SAVE_RESTORE | DLL_ALTMATH;
    #else 
        static WORD wDLLStatus = DLL_SIG_SAVE_RESTORE;
    #endif
#else  
    static char szModule[] = "Application";
#endif

// SignalNaN - by declaring this as a union, it allows the NaN value to be 
// stored as DWORDs directly to a memory location instead of being parsed 
// and  converted by the compiler.  Later, it will be accessed as a floating
// point variable (SignalNan.double) which is inherently an invalid operand
// because it's Not-a-Number.

union SignalNaN_tag {
    double Double;       // this is how we access it as a double float
    struct {
        DWORD Lo;
        DWORD Hi;
    } Qword;                // this is how we access it as a qword integer
} SignalNaN;

// Global variables ...

extern BOOL fMaskExceptions;            // declared in fpstuff.c
UINT uNumExceptions = 0;                // how many sig handler has detected
BOOL fSignalHandlerInstalled = TRUE;

//************************************************************************
//  BOOL GenerateFPException(UINT)
//
//  Description:
//      Generates any of the following Floating Point Exceptions:
//          ZERODIVIDE
//          OVERFLOW
//          UNDERFLOW
//          INVALID
//
//  Returns:
//      TRUE if the exception request was recognized; 
//      FALSE if not.
//
//  Comments:
//      For applications and for DLLs compiled with ALTMATH, simply
//      generate the exception.  But DLLs compiled with EMULATOR, it
//      gets trickier:  first, decide if we want to use _FPInit() and
//      _FPTerm() on our entry points to initialize and terminate Win87Em; 
//      second, decide if we want to install our own signal handler, or 
//      use the default one. 
//
//      Uses #pragma warning() to allow assignment of double to float
//      without the compiler whining about it.
//
//************************************************************************

#pragma optimize ("", off)  // make the compiler stupid so it will allow
                            // the following "mistakes" to generate excepts.
#ifdef _WINDLL
BOOL FAR PASCAL _export DLLGenerateFPException(uExceptionType)
#else
BOOL GenerateFPException(uExceptionType)
#endif
UINT uExceptionType;    // see case statements for parameters
{
    BOOL fReturnVal = TRUE;
    double Double1, Double2;
    float float1;
#if defined(_WINDLL) && defined(EMULATOR)
    PFNSIGNALPROC pfnSigRet;
    LPFNSIGNALPROC lpfnDefaultSignalHandler;

    if (wDLLStatus & DLL_SIG_SAVE_RESTORE)
        lpfnDefaultSignalHandler = _FPInit();

    if (fSignalHandlerInstalled)
        #pragma warning(disable:4113)
        if (( pfnSigRet = signal( SIGFPE, FPHandler )) == SIG_ERR )
        #pragma warning(default:4113)
        {
            DebugSay("\n\rDLL couldn't install its signal handler.");
            if (wDLLStatus & DLL_SIG_SAVE_RESTORE)
                _FPTerm(lpfnDefaultSignalHandler);
            return FALSE;
        }
#endif

#if defined(RESET_EXCEPTION_MASK) && defined(EMULATOR)
    //  Because the floating point control word is not saved/restored
    //  across task switches, we can mask or unmask exceptions as 
    //  appropriate for *this* task.  This doesn't apply to ALTMATH.
    //  fMaskExceptions is our global flag to remember if we want them 
    //  masked or unmasked.
    FPMaskExceptions(fMaskExceptions);
#endif

    switch (uExceptionType)
    {
    case FPE_ZERODIVIDE:
        #ifdef ANNOUNCE_EXCEPTION_TRIGGER
        Say("GenerateFPException : ZeroDivide");
        #endif
        Double1 = 1.0;
        Double2 = 0.0;
        Double1 /= Double2;
        break;

    case FPE_OVERFLOW:
        #ifdef ANNOUNCE_EXCEPTION_TRIGGER
        Say("GenerateFPException : Overflow");
        #endif
        Double1 = Double2 = DBL_MAX;
        Double1 += Double2;
        break;
    
    case FPE_UNDERFLOW:    
        #ifdef ANNOUNCE_EXCEPTION_TRIGGER
        Say("GenerateFPException : Underflow");
        #endif
        // The compiler complains about assigning a double to a float, so
        // temporarily shut it up with a warning #pragma ...
        #pragma warning(disable:4136)
        // assignment into float 1 underflows...
        float1 = Double1 = 1e-40;
        #pragma warning(default:4136)
        break;
    
    case FPE_INVALID:             
        #ifdef ANNOUNCE_EXCEPTION_TRIGGER
        Say("GenerateFPException : Invalid");
        #endif
        // The following is a signaling NaN: 0xfff7ffffffffffff
        SignalNaN.Qword.Hi = 0xfff7ffff;    // Accessing it as a qword int,
        SignalNaN.Qword.Lo = 0xffffffff;    // give it an invalid value.
        Double1 = 1.0 + SignalNaN.Double;   // Now use it.
        break;                  

    default:
        DebugSay("GenerateFPException: Exception request not recognized");
        fReturnVal = FALSE;
        break;
    }
    #if defined(_WINDLL) && defined(EMULATOR)
    if (wDLLStatus & DLL_SIG_SAVE_RESTORE)
        _FPTerm(lpfnDefaultSignalHandler);
    #endif
    return fReturnVal;
} // end of GenerateFPException()
#pragma optimize ("", off)      // restore previous optimization settings


//************************************************************************
//  BOOL  InstallSignalHandler(UINT)
//
//  Description:
//      Installs signal handler for floating point exceptions.
//      Parameter controls which handler gets installed:
//          APP:    App's vs Default
//          DLL:    DLL's vs Default
//
//  Returns:
//      TRUE if signal handler installed;
//      FALSE if not.
//
//************************************************************************

#ifdef _WINDLL
BOOL FAR PASCAL _export DLLInstallSignalHandler(uSignalType)
#else
BOOL InstallSignalHandler(uSignalType)
#endif
UINT uSignalType;       // which signal handler to install:  ours or default
{
    // Initially, the signal handler is whatever default is provided
    // by the C runtime libraries or by Win87Em.  Since this function
    // acts as a toggle, the OldFPHandler function pointer must be 
    // initialized to the our signal handler...

    static void (_cdecl *OldFPHandler)(int, int) = FPHandler;

    switch (uSignalType)
    {
    case SIG_INSTALL:
        #if !defined(EMULATOR) || !defined(_WINDLL)
        if (OldFPHandler != FPHandler)   
        {
            DebugSay("Attempt to re-install signal handler.");
            break;                          // don't reinstall it
        }
        // The following call to signal generates compiler warnings because
        // it's prototyped for only 1 parameter, so shut up this compiler
        // warning temporarily.
        #pragma warning(disable:4113)
        if (( OldFPHandler = signal( SIGFPE, FPHandler )) == SIG_ERR )
        #pragma warning(default:4113)
        {
            DebugSay("\n\rCouldn't install our signal handler.");
            return FALSE;
        }
        #endif
        fSignalHandlerInstalled = TRUE;
        break;

    case SIG_REMOVE:
        #if !defined(EMULATOR) || !defined(_WINDLL)
        if (OldFPHandler == FPHandler)   
        {
            DebugSay("Attempt to re-remove Application signal handler.");
            break;                          // using the default handler
        }

        // The following call to signal generates compiler warnings because
        // it's prototyped for only 1 parameter, so shut up this compiler
        // warning temporarily.
        #pragma warning(disable:4113)
        if (( OldFPHandler = signal( SIGFPE, OldFPHandler )) == SIG_ERR )
        #pragma warning(disable:4113)
        {
            DebugSay("Couldn't restore default signal handler.");
            return FALSE;
        }
        #endif
        fSignalHandlerInstalled = FALSE;
        break;
    }
    return TRUE;
} // end of InstallSignalHandler()


//************************************************************************
//  void FPHandler(sig, subcode)
//
//  Description:
//      App's|DLL's Floating Point exception Handler.  
//      1.  Verifies that we are indeed being called for flt. pt. exception.
//      2.  Increments exception count.
//      3.  Reports what exception occurred.
//      4.  Resets the floating point package.
//
//  Returns:
//      void
//
//  Comments:
//      In the emulator math package, we also save and restore the
//      floating point control word (FCW) around the call to _fpreset()
//      because _fpreset() gives us the default FCW rather than the one
//      we have set.      
//
//************************************************************************

void FPHandler(sig, subcode)
int sig;        // in our case this will always be SIGFPE
int subcode;    // indicates which floating point error occurred
{
#if defined(EMULATOR)
    WORD wFCW;      // floating point control word
#endif

    if (sig != SIGFPE)
    {
        DebugSay("Signal error: exception should be SIGFPE.");
        return;
    }
    uNumExceptions++;           // Increase count of exceptions detected

    FPExceptionInfo(subcode);   // Report on what type of exception occurred

    //  Reset floating point package.  Note that this sets the floating point
    //  control word (FCW) back to its initial _CW_DEFAULT value (see 
    //  FLOAT.H); the default masks denormal, underflow, and inexact 
    //  exceptions.  If we don't do something about that, then we might no 
    //  longer see exceptions that we wanted to see; consequently, we 
    //  save/restore the FCW around _fpreset().

#if defined(EMULATOR)
    wFCW = _control87(0,0);         // Get the current control word
#endif
    _fpreset();                     // Reset the floating point package
#if defined(EMULATOR)
    _control87(wFCW, 0xffff);       // Restore previous control word
#endif
} // end of FPHandler()


//************************************************************************
//  void FPExceptionInfo(uSignalSubcode)
//
//  Description:
//      Reports on what type of exception occurred according to 
//      uSignalSubcode parameter.  
//
//  Returns:
//      nothing
//
//************************************************************************

void FPExceptionInfo(uSignalSubcode)
UINT uSignalSubcode;                    // signal type passed to handler
{
    char szExceptionType[80];

    switch (uSignalSubcode)     // global variable set by exception handler
    {
    case FPE_INVALID:
        lstrcpy(szExceptionType, "INVALID");
        break;
     
    case FPE_DENORMAL:
        lstrcpy(szExceptionType, "DENORMAL");
        break;

    case FPE_ZERODIVIDE:
        lstrcpy(szExceptionType, "ZERODIVIDE");
        break;

    case FPE_OVERFLOW:
        lstrcpy(szExceptionType, "OVERFLOW");
        break;

    case FPE_UNDERFLOW:
        lstrcpy(szExceptionType, "UNDERFLOW");
        break;

    case FPE_INEXACT:
        lstrcpy(szExceptionType, "INEXACT");
        break;

    case FPE_UNEMULATED:
        lstrcpy(szExceptionType, "UNEMULATED");
        break;

    case FPE_SQRTNEG:
        lstrcpy(szExceptionType, "SQRTNEG");
        break;

    case FPE_STACKOVERFLOW:
        lstrcpy(szExceptionType, "STACKOVERFLOW");
        break;

    case FPE_STACKUNDERFLOW:
        lstrcpy(szExceptionType, "STACKUNDERFLOW");
        break;

    case FPE_EXPLICITGEN:
        lstrcpy(szExceptionType, "EXPLICITGEN");
        break;

    default:
        lstrcpy(szExceptionType, "Other exception type");
        break;
    }
    Say2("%s signal handler detected %s exception.",
        (LPSTR) szModule,
        (LPSTR) szExceptionType);
} // end of FPExceptionInfo()


//************************************************************************
//  DWORD DLLGetStatus(UINT uStatusType)
//
//  Description:
//      Retrieves status information from DLL:  What math package
//      it's compiled with, whether its exception handler is 
//      installed, and how many exceptions its signal handler 
//      has detected.
//
//  Returns:
//      DWORD containing:
//          HIWORD == number of exceptions trapped by DLL sig. handler
//          LOWORD == status mask:
//              DLL_ALTMATH       == 1|0 to indicate which math package
//              DLL_SIG_INSTALLED == 0|1 to indicate if DLL's signal
//                                   handler is installed.
//  Comments:
//      This function is only compiled if generating code for DLL.
//
//************************************************************************

#ifdef _WINDLL
DWORD FAR PASCAL _export DLLGetStatus(uStatusType)
UINT uStatusType;                // Reserved:  set to 0;
{
    if (fSignalHandlerInstalled)
        wDLLStatus |= DLL_SIG_INSTALLED;
    else
        wDLLStatus &= ~DLL_SIG_INSTALLED;
    return MAKELONG(wDLLStatus, uNumExceptions);
} // end of DLLGetStatus()
#endif


//************************************************************************
//  WORD DLLSetStatus(UINT uStatus)
//
//  Description:
//      Sets status variable in DLL to tell it whether or not
//      it should use _FPInit()/_FPTerm() to control Win87Em
//      library at DLL's entry and exit points.
//
//  Returns:
//      Previous value of DLL status word.
//      
//  Comments:
//      This function is only compiled if generating code for DLL.
//
//************************************************************************

#ifdef _WINDLL
WORD FAR PASCAL _export DLLSetStatus(uStatusType)
UINT uStatusType;       // What to do:  set or clear status value
{
    WORD wOldDLLStatus = wDLLStatus;

    switch (uStatusType)
    {
        case IDM_DLL_SIG_SAVE_RESTORE:
            wDLLStatus |= DLL_SIG_SAVE_RESTORE;
            break;

        case IDM_DLL_SIG_NOSAVE_RESTORE:
            wDLLStatus &= ~DLL_SIG_SAVE_RESTORE;
            break;
        
        default:
            DebugSay ("DLLSetStatus: Unknown status type");
    }
    return wOldDLLStatus;
} // end of DLLSetStatus()
#endif

//***************************************************************************
//  End of File: FPExcept.c
//***************************************************************************

