//***************************************************************************
//
//  Module:   floatdos.c
//
//  Purpose:
//      A "DOSified" version of the Windows FloatApp.  Allows comparison
//      of speed and exception handling in DOS vs Windows.  Note that some 
//      Windows functions are redefined for DOS equivalents, such as 
//      wsprintf() ==> sprintf().  Also note that some <windows.h> type 
//      declarations are provided here, such as DWORD, BOOL, etc.
//
//  Description of functions:
//      main - Presents menu, gets keyboard choice, executes function.
//               (Simulates Windows' WM_COMMAND message).
//      TestFloatSpeed()        Timing loop for floating point speed.
//      GenerateFPException()   Triggers various types of FP exceptions.                
//      InstallSignalHandler()  Installs application or default handler.
//      FPStatus()              Reports status for floating point issues.
//      AppFPHandler()          The application's signal handler.
//      FPExceptionInfo()       Reports what exception type occured.
//      FPMaskExceptions()      Allows or prevents exceptions to occur.
//
//      (See FloatApp for fuller descriptions of functions.)
//
//---------------------------------------------------------------------------
// COPYRIGHT:
//
//   (C) Copyright Microsoft Corp. 1993.  All rights reserved.
//
//   You have a royalty-free right to use, modify, reproduce and
//   distribute the Sample Files (and/or any modified version) in
//   any way you find useful, provided that you agree that
//   Microsoft has no warranty obligations or liability for any
//   Sample Application Files which are modified.
//

#include <stdio.h>
#include <conio.h>      // for getch()
#include <ctype.h>      // for toupper()
#include <signal.h>
#include <setjmp.h>
#include <float.h>
#include <time.h>       // for clock()
#include <string.h>

#if !defined(ALTMATH) && !defined(EMULATOR)
#pragma message("No math package defined; assuming Emulator")
#define EMULATOR
#endif

// The following defines allow reuse of Windows code in DOS app with 
// minimal porting hassle...

#define UINT unsigned int
#define BOOL UINT
#define DWORD unsigned long
#define DEBUG_OUT printf
#define wsprintf sprintf
#define lstrcpy strcpy
#define FALSE 0
#define TRUE  1

// The following defines are from FLOATAPP.H

#define IDM_SIGNAL_APPLICATION      140
#define IDM_SIGNAL_DEFAULT          141
#define NO_EXCEPTION 0

// Function prototypes...

void main(void);
BOOL FPMaskExceptions(BOOL);
DWORD TestFloatSpeed(UINT);
void AppFPHandler(int, int);
BOOL FPMaskExceptions(BOOL);
BOOL GenerateFPException(UINT);
void FPExceptionInfo(void);
BOOL FPStatus(UINT);
BOOL InstallSignalHandler(UINT);

// Global variables...

static UINT uSignalSubcode;
static UINT uNumExceptions=0;
BOOL fMaskExceptions = FALSE;
BOOL fAppSignalHandler = TRUE;
jmp_buf mark;

// By declaring this as a union, it allows the NaN value to be stored as
// DWORDs directly to a memory location instead of being parsed and 
// converted by the compiler.  Later, it will be accessed as a floating
// point variable (dfSignalNan) which is inherently an invalid operand
// because it's Not-a-Number.

union SignalNaN_tag {
    double doubleNaN;       // this is how we access it as a double float
    struct {
        DWORD qwLo;
        DWORD qwHi;
    } Qword;                // this is how we access it as a qword integer
} SignalNaN;

//***************************************************************************

void main(void)
{
    int c;

    // Initially, set the signal handler to be application's own;
    // the user can change this later with menu choices ...

    InstallSignalHandler(IDM_SIGNAL_APPLICATION);

    while (TRUE)
    {
        printf("\nChoose:\n");
        printf("\t(P)erformance test\n");
        printf("\t(S)tatus report\n");
        printf("\t(E)xception test\n");
        printf("\t(M)ask exceptions\n");
        printf("\t(U)nmask exceptions\n");
        printf("\t(A)pplication signal handler\n");
        printf("\t(D)efault signal handler\n");
        printf("\t(Q)uit\n\n");
        
        // poll for character in {A..Z}
        flushall();
        do {
            c = getch();
            c = toupper(c);
        } while ((c < 'A') || (c > 'Z'));

        switch(c)
        {
            case 'P':
                TestFloatSpeed(0);
                break;

            case 'S':
                printf("Status report...\n");
                FPStatus(1);
                break;

            case 'E':
            {
                int c;
                BOOL fWaitForChoice = TRUE;

                printf("\nChoose type of exception to generate:\n");
                printf("\t(Z)eroDivide\n");
                printf("\t(O)verflow\n");
                printf("\t(U)nderflow\n");
                printf("\t(I)nvalid\n");
                printf("\t(N)one\n");

                flushall();
                while (fWaitForChoice)
                {
                    do {                // poll for character in {A..Z}
                        c = getch();
                        c = toupper(c);
                    } while ((c < 'A') || (c > 'Z'));

                    switch(c)
                    {
                        case 'Z':
                            GenerateFPException(FPE_ZERODIVIDE);
                            break;

                        case 'O':
                            GenerateFPException(FPE_OVERFLOW);
                            break;

                        case 'U':
                            GenerateFPException(FPE_UNDERFLOW);
                            break;
                        
                        case 'I':
                            GenerateFPException(FPE_INVALID);
                            break;

                        case 'N':
                            break;

                        default:  // wasn't valid; choose again
                            // fWaitForChoice = TRUE;
                            continue;
                    } // switch
                    fWaitForChoice = FALSE;   // assume we have a valid one
                } // while
            } // case 'E'
                break;

            case 'M':
                #if defined(ALTMATH)
                printf("\nCannot mask exceptions in alternate math.\n");
                #elif defined(EMULATOR)
                printf("\nMasking exceptions.\n");
                fMaskExceptions = TRUE;
                FPMaskExceptions(fMaskExceptions);
                #endif
                break;

            case 'U':
                #if defined(ALTMATH)
                printf("\nCannot unmask exceptions in alternate math.\n");
                #elif defined(EMULATOR)
                printf("\nUnmasking exceptions.\n");
                fMaskExceptions = FALSE;
                FPMaskExceptions(fMaskExceptions);
                #endif
                break;

            case 'A':
                printf("Installing application signal handler\n");
                fAppSignalHandler = TRUE;
                InstallSignalHandler(IDM_SIGNAL_APPLICATION);
                break;

            case 'D':
                printf("Installing default signal handler\n");
                fAppSignalHandler = FALSE;
                InstallSignalHandler(IDM_SIGNAL_DEFAULT);
                break;

            case 'Q':
                printf("Bye.\n");
                return;

            default:
                // character not interesting; go back for another
                break;
        } // switch
    } // while
} // main


//***************************************************************************

#pragma optimize("",off)

DWORD TestFloatSpeed(uTestType)
UINT uTestType;
{
    clock_t dwStartTime, dwEndTime; // tick counts for timing operation
    char szMessage[80];             // message to debug monitor    
    UINT i, j;                      // loop counters
    double double1, double2, double3;  // variables to perform fp operations on

    DEBUG_OUT("\n\n\rPerforming floating point calculation loop...\n\r");
    dwStartTime = clock();

    double1 = 1.0;                          // Initialize the variables
    double2 = 2.0;                          // to some simplistic starting
    double3 = 3.0;                          // starting values.

    for (i=0; i < 4; i++)                   // Let's party...
    {
        for (j=0; j < 0xffff; j++)
        {
            double1 = double2 + double3;   
            double1 = double2 * double3;   
            double1 = double2 - double3;   
            double1 = double2 / double3;    // this causes an inexact 
        }                                   // exception unless it's masked.
    }
    dwEndTime = clock();

    wsprintf (szMessage, "dwStartTime = %lu\n\r", dwStartTime);
    DEBUG_OUT (szMessage);
    wsprintf (szMessage, "dwEndTime = %lu\n\r", dwEndTime);
    DEBUG_OUT (szMessage);

    wsprintf (szMessage, "Time spent calculating = %lu milliseconds.\n\r",
        (DWORD) dwEndTime-dwStartTime);
    DEBUG_OUT (szMessage);

    return (dwEndTime - dwStartTime);
} // end of TestFloatSpeed()

#pragma optimize("",off)


//***************************************************************************

BOOL FPStatus(uStatusType)
UINT uStatusType;
{
#ifdef EMULATOR
    UINT fpcontrol;                     // floating point control word
    char szMessage[80];                 // for outputting info. messages
#endif

#if defined(ALTMATH)                    // this is not automatically 
    char * szMathLib = "Alternate math";// provided by the compiler;
#elif defined (EMULATOR)                // the makefile for this app
    char * szMathLib = "Emulator math"; // explicitly declares these
#else
    char * szMathLib = "Math package undefined";
#endif

    DEBUG_OUT("\n\rApplication compiled with ");
    DEBUG_OUT(szMathLib);
    DEBUG_OUT("\n\r");

#ifdef EMULATOR
    // Report the value of the floating point control word ...
    
    fpcontrol = _control87(0,0);
    wsprintf (szMessage, "Floating point control word is 0x%x\n\r", fpcontrol);
    DEBUG_OUT(szMessage);
#endif

    printf("Using %s signal handler.\n",
        fAppSignalHandler ? "application" : "default");

    return TRUE;
} // end of FPStatus()


//***************************************************************************

void AppFPHandler(sig, subcode)
int sig;        // in our case this will always be SIGFPE
int subcode;    // indicates which floating point error occured
{
    if (sig != SIGFPE)
    {
        DEBUG_OUT("Signal error: exception should be SIGFPE.\n\r");
        return;
    }
    uSignalSubcode = subcode;   // Store exception type in global variable
                                // for later examination.
    uNumExceptions++;           // Increase count of exceptions detected

    // Reset floating point package; note that in the EMULATOR package, this
    // sets the 87 control word back to its initial CW_DEFAULT value (see 
    // FLOAT.H), which masks denormal, underflow, and inexact exceptions.  
    // If we don't do something about that, then we might no longer see 
    // exceptions that we wanted to see; thus, the follow-up call to 
    // FPMaskExceptions().

    _fpreset();

    longjmp(mark, subcode);     // jump to where setjmp() was called

} // end of AppFPHandler()


//***************************************************************************

BOOL FPMaskExceptions(fMask)
BOOL fMask;     // TRUE = mask them; FALSE = unmask them
{
#ifdef EMULATOR
    if (fMask)
        // prevent exceptions from occuring...
        _control87(EM_INVALID | EM_DENORMAL | EM_ZERODIVIDE |
                   EM_OVERFLOW | EM_UNDERFLOW | EM_INEXACT,
                   MCW_EM);
    else
        // allow exceptions to occur (except for inexact, which occurs 
        // far too frequently) ...
        _control87(EM_INEXACT, MCW_EM);
#endif
    return fMask;
} // end of FPMaskExceptions()


//***************************************************************************

#pragma optimize("",off)

BOOL GenerateFPException(uExceptionType)
UINT uExceptionType;
{
    double double1, double2;
    float float1;
    int jmpret;
    
    uSignalSubcode = NO_EXCEPTION;  // Signal handler will set this

    jmpret = setjmp(mark);
    if (jmpret != 0)    // we had an exception and got here via longjmp()
    {
        FPExceptionInfo();  // report what the exception was
        return TRUE;
    }
    DEBUG_OUT("\n\n\rAbout to Generate FP Exception : ");
    switch (uExceptionType)
    {
    case FPE_ZERODIVIDE:
        DEBUG_OUT("ZeroDivide\n\r");
        double1 = 1.0;
        double2 = 0.0;
        double1 /= double2;  
        break;

    case FPE_OVERFLOW:
        DEBUG_OUT("Overflow\n\r");
        double1 = double2 = DBL_MAX;
        double1 += double2;
        break;
    
    case FPE_UNDERFLOW:    
        DEBUG_OUT("Underflow\n\r");
        // The compiler complains about assigning a double to a float, so
        // temporarily shut it up with a warning #pragma ...
        #pragma warning(disable:4136) 
        // assignment into float 1 underflows...
        float1 = double1 = 1e-40;
        #pragma warning(default:4136) 
        break;
   
    case FPE_INVALID:               // HELP!  this doesn't work yet!  :-(
        DEBUG_OUT("Invalid\n\r");
        // The following is a signaling NaN: 0xfff7ffffffffffff
        SignalNaN.Qword.qwHi = 0xfff7ffff;  // Accessing it as a qword int,
        SignalNaN.Qword.qwLo = 0xffffffff;  // give it an invalid value.
        double1 = SignalNaN.doubleNaN;      // Now load it as a double float
        double1 += 1.0;                     // and use it.
        break;

    default:
        DEBUG_OUT("Exception request not recognized\n\r");
        return FALSE;
    }
    DEBUG_OUT("No Exception detected by signal handler\n\r");
    return TRUE;   // should never get here because of setjmp()/longjmp()
} // end of GenerateFPException()

#pragma optimize("",on)

//***************************************************************************

void FPExceptionInfo(void)
{
    char szExceptionType[80];

    switch (uSignalSubcode)     // global variable set by exception handler
    {
    case FPE_INVALID:
        lstrcpy(szExceptionType, "INVALID");
        break;
     
    case FPE_DENORMAL:
        lstrcpy(szExceptionType, "DENORMAL");
        break;

    case FPE_ZERODIVIDE:
        lstrcpy(szExceptionType, "ZERODIVIDE");
        break;

    case FPE_OVERFLOW:
        lstrcpy(szExceptionType, "OVERFLOW");
        break;

    case FPE_UNDERFLOW:
        lstrcpy(szExceptionType, "UNDERFLOW");
        break;

    case FPE_INEXACT:
        lstrcpy(szExceptionType, "INEXACT");
        break;

    case FPE_UNEMULATED:
        lstrcpy(szExceptionType, "UNEMULATED");
        break;

    case FPE_SQRTNEG:
        lstrcpy(szExceptionType, "SQRTNEG");
        break;

    case FPE_STACKOVERFLOW:
        lstrcpy(szExceptionType, "STACKOVERFLOW");
        break;

    case FPE_STACKUNDERFLOW:
        lstrcpy(szExceptionType, "STACKUNDERFLOW");
        break;

    case FPE_EXPLICITGEN:
        lstrcpy(szExceptionType, "EXPLICITGEN");
        break;

    case NO_EXCEPTION:
        lstrcpy(szExceptionType, "no");
        break;

    default:
        lstrcpy(szExceptionType, "Other exception type");
        break;
    }
    DEBUG_OUT("Signal handler detected ");
    DEBUG_OUT(szExceptionType);
    DEBUG_OUT(" exception.\n\r");
    uSignalSubcode = NO_EXCEPTION;  // reset flag to indicate no exceptions
} // end of FPExceptionInfo()

//***************************************************************************

BOOL InstallSignalHandler(uSignalType)
UINT uSignalType;       // which signal handler to install:  app vs default
{
    static void (_cdecl *OldFPHandler)(int, int) = AppFPHandler;

    switch (uSignalType)
    {
    case IDM_SIGNAL_APPLICATION:
        if (OldFPHandler != AppFPHandler)   // we're already using it
            break;

        // The following call to signal generates compiler warnings because
        // it's prototyped for only 1 parameter, so shut up this compiler
        // warning temporarily.
        #pragma warning(disable:4113) 
        if ((OldFPHandler = signal(SIGFPE, AppFPHandler)) == SIG_ERR)
        #pragma warning(default:4113) 
        {
            DEBUG_OUT ("Couldn't install application signal handler.\n\r");
            return FALSE;
        }
        break;

    case IDM_SIGNAL_DEFAULT:
        if (OldFPHandler == AppFPHandler)   // already using default
            break;

        // The following call to signal generates compiler warnings because
        // it's prototyped for only 1 parameter, so shut up this compiler
        // warning temporarily.
        #pragma warning(disable:4113) 
        if ((OldFPHandler = signal(SIGFPE, OldFPHandler)) == SIG_ERR)
        #pragma warning(disable:4113) 
        {
            DEBUG_OUT ("Couldn't restore default signal handler.\n\r");
            return FALSE;
        }
        break;
    }
    return TRUE;
} // end of InstallSignalHandler()


//***************************************************************************
//  End of File: floatdos.c
//***************************************************************************

